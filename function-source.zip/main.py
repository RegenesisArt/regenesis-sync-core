from flask import render_template, jsonify, request
import functions_framework
from datetime import datetime
import json

# In-memory database
artworks_db = {}
financial_db = {
    "the_key": {"target": 6000, "current": 0},
    "freedom_fuel": {"target": 10000, "current": 0},
    "apv_total": 0
}

@functions_framework.http
def app(request):
    path = request.path
    method = request.method
    
    # ========== DASHBOARD ROUTES ==========
    
    # Main dashboard page
    if path == '/dashboard':
        return render_template('dashboard.html')
    
    # Dashboard API
    if path == '/api/dashboard':
        try:
            total_artworks = len(artworks_db)
            artworks_in_progress = len([a for a in artworks_db.values() if a.get("status") == "in_progress"])
            
            return jsonify({
                "dashboard": {
                    "status": "live",
                    "timestamp": datetime.now().isoformat(),
                    "metrics": {
                        "hub": "online",
                        "artworks_total": total_artworks,
                        "artworks_active": artworks_in_progress
                    }
                }
            })
        except Exception as e:
            return jsonify({"error": str(e)})
    
    # Command API
    if path == '/api/command' and method == 'POST':
        data = request.get_json() or {}
        command = data.get('command', '').lower()
        
        responses = {
            'cycle subjects': {
                "response": """Generating 3 UNFILTERED COMMERCIAL suggestions...
                
1. 🐕 Custom Pet Portrait (Golden Retriever)
   • Tier: 1 | Target: $75-100
   • Market: High demand on eBay
   • ETC: 2-3 hours
            
2. 🏔️ Mountain Landscape at Sunset
   • Tier: 2 | Target: $450-600  
   • Market: Consistent collector interest
   • ETC: 8-10 hours
            
3. 🔺 Abstract Geometric Pattern
   • Tier: 1 | Target: $60-80
   • Market: Modern decor trend
   • ETC: 3-4 hours
            
Command: 'Accept subject #[1-3]'"""
            },
            'update metrics': {
                "response": "Dashboard metrics refreshed from live CMHP sync."
            },
            'genesis sprint': {
                "response": "🔥 GENESIS SPRINT ACTIVATED 🔥\nPhase 1: Ceremonial Selection\nPhase 2: Ritual Preparation\nPhase 3: First Stroke Ceremony"
            },
            'show alerts': {
                "response": "🔴 ACTIVE ALERTS:\n1. Genesis Quest selection pending\n2. Zero eBay listings\n3. YouTube pipeline empty"
            }
        }
        
        if command in responses:
            return jsonify(responses[command])
        else:
            return jsonify({
                "response": f"Processing: '{command}'\nConnecting to DeepSeek API..."
            })
    
    # Root endpoint
    if path in ['/', '/health']:
        return jsonify({
            "system": "Regenesis Hub V8.0",
            "status": "operational",
            "dashboard": "available at /dashboard",
            "api": "available at /api/dashboard",
            "timestamp": datetime.now().isoformat()
        })
    
    # Default 404
    return jsonify({"error": "Endpoint not found"}), 404
